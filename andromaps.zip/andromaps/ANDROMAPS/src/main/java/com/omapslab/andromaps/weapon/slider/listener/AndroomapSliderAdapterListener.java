package com.omapslab.andromaps.weapon.slider.listener;

import android.view.ViewGroup;

/**
 * Created by omapslab on 6/10/17.
 */

public interface AndroomapSliderAdapterListener {

    void onGenerateSlider(ViewGroup rootView, Object sliderSample, int Position);
}
